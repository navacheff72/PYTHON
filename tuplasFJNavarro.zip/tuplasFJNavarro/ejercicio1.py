"""Ejercicio 1:
A. Crea una tupla con los nombres de los días de la semana."""
semana=("lunes","martes","miercoles","jueves","viernes","sabado","domingo")
print(semana)
#B. Imprime el tercer día de la semana.
print(semana[2])
#C. Imprime los días de la semana en orden inverso."""
print(semana[::-1])