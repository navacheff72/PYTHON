"""Ejercicio 4:
 A. Crea una tupla de tuplas para representar una matriz de 3x3."""

tupla=(("a","b","c"),(1,2,3),("x","+","-"))
print(tupla)
""" B. Imprime el elemento en la segunda fila y tercera columna. """
print(tupla[1][2])
