lista=(1,2,3,4,5,6)
print (lista)
num=len(lista)
print (num)
for i in num :
    if lista[i]> 2 :
        print (lista[i])

