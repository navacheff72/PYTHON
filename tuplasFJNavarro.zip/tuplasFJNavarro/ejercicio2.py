"""Ejercicio 2:
A. Crea una tupla con tus datos personales (nombre, apellido, edad)."""
datos=("Francisco","Navarro",52)
print(datos)
#B. Imprime una frase que incluya tus datos.
print("El Señor ",datos[0]," ",datos[1], " tiene ",datos[2]," años")